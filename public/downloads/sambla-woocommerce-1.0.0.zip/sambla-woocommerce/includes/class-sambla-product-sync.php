<?php
if (!defined('ABSPATH')) exit;

class Sambla_Product_Sync {
    public function __construct() {
        add_action('woocommerce_new_product', [$this, 'sync_single']);
        add_action('woocommerce_update_product', [$this, 'sync_single']);
        add_action('woocommerce_delete_product', [$this, 'delete_product']);
        add_action('woocommerce_trash_product', [$this, 'delete_product']);
    }

    public function sync_single($product_id) {
        if (!get_option('sambla_connected')) return;
        $product = wc_get_product($product_id);
        if (!$product || $product->get_status() !== 'publish') return;
        (new Sambla_Api_Client())->sync_products([$this->format($product)], home_url());
    }

    public function delete_product($product_id) {
        if (!get_option('sambla_connected')) return;
        (new Sambla_Api_Client())->sync_products([], home_url(), [$product_id]);
    }

    public function full_sync() {
        if (!get_option('sambla_connected')) return ['error' => 'Nu ești conectat la Sambla.'];

        $products = wc_get_products(['status' => 'publish', 'limit' => -1, 'type' => ['simple', 'variable']]);
        if (empty($products)) return ['synced' => 0];

        $client = new Sambla_Api_Client();
        $formatted = array_map([$this, 'format'], $products);
        $batches = array_chunk($formatted, 50);
        $total = 0;

        foreach ($batches as $batch) {
            $r = $client->sync_products($batch, home_url());
            if (isset($r['synced'])) $total += $r['synced'];
        }

        update_option('sambla_last_sync', current_time('mysql'));
        return ['synced' => $total, 'total' => count($products)];
    }

    private function format($product) {
        $image_id = $product->get_image_id();
        $cats = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'names']);

        // Get attributes
        $attrs = [];
        foreach ($product->get_attributes() as $attr) {
            if (is_object($attr)) {
                $name = wc_attribute_label($attr->get_name());
                $values = $attr->is_taxonomy()
                    ? wp_get_post_terms($product->get_id(), $attr->get_name(), ['fields' => 'names'])
                    : $attr->get_options();
                $attrs[$name] = is_array($values) ? $values : [$values];
            }
        }

        return [
            'wc_product_id' => $product->get_id(),
            'name' => $product->get_name(),
            'short_description' => wp_strip_all_tags($product->get_short_description()),
            'description' => wp_strip_all_tags($product->get_description()),
            'price' => (float) $product->get_price(),
            'regular_price' => (float) $product->get_regular_price(),
            'sale_price' => $product->get_sale_price() ? (float) $product->get_sale_price() : null,
            'currency' => get_woocommerce_currency(),
            'sku' => $product->get_sku(),
            'stock_status' => $product->get_stock_status(),
            'image_url' => $image_id ? wp_get_attachment_image_url($image_id, 'medium') : '',
            'categories' => is_array($cats) ? $cats : [],
            'attributes' => $attrs,
            'permalink' => $product->get_permalink(),
        ];
    }
}
