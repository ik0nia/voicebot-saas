<div class="wrap">
    <h1 style="display:flex;align-items:center;gap:8px;">
        <span style="background:#991b1b;color:#fff;width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:8px;font-weight:bold;font-size:16px;">S</span>
        Sambla AI Chat
    </h1>

    <div id="sambla-notices"></div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:20px;max-width:1200px;">

        <!-- Connection -->
        <div class="card" style="padding:20px;">
            <h2 style="margin-top:0;">Conexiune</h2>
            <?php if ($connected): ?>
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:15px;padding:10px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;">
                    <span style="width:10px;height:10px;background:#22c55e;border-radius:50%;display:inline-block;"></span>
                    <strong style="color:#15803d;">Conectat</strong>
                </div>
                <p class="description">Bot ID: <?php echo esc_html(get_option('sambla_bot_id')); ?></p>
                <p class="description">Channel ID: <?php echo esc_html(get_option('sambla_channel_id')); ?></p>
                <br>
                <button class="button" id="sambla-disconnect">Deconectează</button>
            <?php else: ?>
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:15px;padding:10px;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;">
                    <span style="width:10px;height:10px;background:#ef4444;border-radius:50%;display:inline-block;"></span>
                    <strong style="color:#dc2626;">Neconectat</strong>
                </div>
                <table class="form-table">
                    <tr>
                        <th><label for="sambla-api-key">API Key</label></th>
                        <td>
                            <input type="password" id="sambla-api-key" class="regular-text" value="<?php echo esc_attr($api_key); ?>">
                            <p class="description">Găsești API Key-ul în <a href="https://sambla.ro/dashboard/setari" target="_blank">Sambla → Setări → API Keys</a></p>
                        </td>
                    </tr>
                </table>
                <button class="button button-primary" id="sambla-connect">Conectează</button>
            <?php endif; ?>
        </div>

        <!-- Sync -->
        <div class="card" style="padding:20px;">
            <h2 style="margin-top:0;">Sincronizare Produse</h2>
            <?php if ($connected): ?>
                <table class="form-table" style="margin:0;">
                    <tr>
                        <th>Ultima sincronizare</th>
                        <td><?php echo $last_sync ?: '<em>Niciodată</em>'; ?></td>
                    </tr>
                </table>
                <br>
                <button class="button button-primary" id="sambla-sync">Sincronizează Acum</button>
                <span id="sambla-sync-status" style="margin-left:10px;"></span>
                <p class="description" style="margin-top:8px;">Produsele se sincronizează automat la modificare. Acest buton face sincronizare completă.</p>
            <?php else: ?>
                <p class="description">Conectează-te pentru a sincroniza produsele.</p>
            <?php endif; ?>
        </div>

        <?php if ($connected): ?>
        <!-- Design -->
        <div class="card" style="padding:20px;grid-column:1/3;">
            <h2 style="margin-top:0;">Design Chatbot</h2>
            <table class="form-table" style="margin:0;">
                <tr>
                    <th><label for="sambla-bot-name">Nume Bot</label></th>
                    <td><input type="text" id="sambla-bot-name" class="regular-text" value="<?php echo esc_attr($config['bot_name'] ?? ''); ?>"></td>
                </tr>
                <tr>
                    <th><label for="sambla-color">Culoare</label></th>
                    <td><input type="text" id="sambla-color" class="sambla-color-picker" value="<?php echo esc_attr($config['color'] ?? '#991b1b'); ?>"></td>
                </tr>
                <tr>
                    <th><label>Icon</label></th>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <input type="text" id="sambla-icon-url" class="regular-text" value="<?php echo esc_attr($config['icon_url'] ?? ''); ?>" placeholder="URL sau alege din media">
                            <button type="button" class="button" id="sambla-upload-icon">Alege imagine</button>
                            <?php if (!empty($config['icon_url'])): ?>
                                <img src="<?php echo esc_url($config['icon_url']); ?>" style="width:40px;height:40px;border-radius:50%;object-fit:cover;" id="sambla-icon-preview">
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th><label for="sambla-position">Poziție</label></th>
                    <td>
                        <select id="sambla-position">
                            <option value="bottom-right" <?php selected($config['position'] ?? '', 'bottom-right'); ?>>Dreapta jos</option>
                            <option value="bottom-left" <?php selected($config['position'] ?? '', 'bottom-left'); ?>>Stânga jos</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="sambla-greeting">Mesaj întâmpinare</label></th>
                    <td><textarea id="sambla-greeting" class="large-text" rows="2"><?php echo esc_textarea($config['greeting'] ?? ''); ?></textarea></td>
                </tr>
            </table>
            <br>
            <button class="button button-primary" id="sambla-save-settings">Salvează Setările</button>
        </div>
        <?php endif; ?>
    </div>
</div>
