jQuery(document).ready(function($) {
    $('.sambla-color-picker').wpColorPicker();

    $('#sambla-upload-icon').on('click', function(e) {
        e.preventDefault();
        var frame = wp.media({ title: 'Alege icon', button: { text: 'Folosește' }, multiple: false, library: { type: 'image' } });
        frame.on('select', function() {
            var url = frame.state().get('selection').first().toJSON().url;
            $('#sambla-icon-url').val(url);
            if ($('#sambla-icon-preview').length) $('#sambla-icon-preview').attr('src', url);
            else $('#sambla-icon-url').after('<img src="'+url+'" style="width:40px;height:40px;border-radius:50%;object-fit:cover;" id="sambla-icon-preview">');
        });
        frame.open();
    });

    $('#sambla-connect').on('click', function() {
        var btn = $(this), key = $('#sambla-api-key').val().trim();
        if (!key) { notice('error', 'Introdu API Key-ul.'); return; }
        btn.prop('disabled', true).text('Se conectează...');
        $.post(samblaAdmin.ajaxUrl, { action: 'sambla_connect', nonce: samblaAdmin.nonce, api_key: key }, function(r) {
            if (r.success) { notice('success', r.data.message); setTimeout(function(){location.reload();}, 1000); }
            else { notice('error', r.data.message); btn.prop('disabled', false).text('Conectează'); }
        });
    });

    $('#sambla-disconnect').on('click', function() {
        if (!confirm('Sigur?')) return;
        $.post(samblaAdmin.ajaxUrl, { action: 'sambla_disconnect', nonce: samblaAdmin.nonce }, function() {
            notice('success', 'Deconectat.'); setTimeout(function(){location.reload();}, 1000);
        });
    });

    $('#sambla-sync').on('click', function() {
        var btn = $(this);
        btn.prop('disabled', true); $('#sambla-sync-status').text('Se sincronizează...');
        $.post(samblaAdmin.ajaxUrl, { action: 'sambla_sync_now', nonce: samblaAdmin.nonce }, function(r) {
            btn.prop('disabled', false);
            if (r.success) { $('#sambla-sync-status').text('✓ Gata!'); notice('success', r.data.message); }
            else { $('#sambla-sync-status').text('✗ Eroare'); notice('error', r.data.message); }
        });
    });

    $('#sambla-save-settings').on('click', function() {
        var btn = $(this);
        btn.prop('disabled', true).text('Se salvează...');
        $.post(samblaAdmin.ajaxUrl, {
            action: 'sambla_save_settings', nonce: samblaAdmin.nonce,
            bot_name: $('#sambla-bot-name').val(), color: $('#sambla-color').val(),
            icon_url: $('#sambla-icon-url').val(), position: $('#sambla-position').val(),
            greeting: $('#sambla-greeting').val()
        }, function(r) {
            btn.prop('disabled', false).text('Salvează Setările');
            notice(r.success ? 'success' : 'error', r.data.message);
        });
    });

    function notice(type, msg) {
        $('#sambla-notices').html('<div class="notice notice-'+type+' is-dismissible"><p>'+msg+'</p></div>');
        setTimeout(function(){ $('#sambla-notices').html(''); }, 5000);
    }
});
